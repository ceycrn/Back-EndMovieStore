﻿using Core.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Utilities.Security.JWT
{
    public interface ITokenHelper
    {
        //eger kullanıcının girdiği bilgiler dogru ise örnegin giriş ekranındaki bilgiler..Burada onun için bir token üretilir.
        AccessToken CreateToken(User user, List<OperationClaim> operationClaims);
    }
}