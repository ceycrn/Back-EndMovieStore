﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Utilities.Results
{
    public class Result : IResult
    {
        private string productAdded;

        public Result(bool success, string message) : this(success) //Result'ın tek parametreli olan asagidaki constructor'a success bilgisini gönder. message2ı da iceride isle
        {
            Message = message;
        }

        public Result(bool success)
        {
            Success = success;
        }

        public bool Success { get; }

        public string Message { get; }
    }
}