﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.CCS
{
    public class Logger: ILogger
    {
        public void LogLoginTime<T>(T variable)
        {
            string logFolderPath = "Logs"; // "Logs" klasörünün adını kullanın
            string logFileName = "myapplog.json"; // Log dosyasının adı
            string logFilePath = Path.Combine(logFolderPath, logFileName);
         

            var jsonLog = JsonConvert.SerializeObject(variable);

            System.IO.File.AppendAllText(logFilePath, jsonLog + Environment.NewLine);
        }
    }
}
